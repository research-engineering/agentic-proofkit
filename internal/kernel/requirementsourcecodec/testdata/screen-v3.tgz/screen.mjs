import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { basename, dirname, join } from "node:path";

const OMIT = Symbol("omit");
const collectionKeys = new Set([
  "sourceNonClaimRefs", "nonClaimDefinitions", "vocabulary", "derivations",
  "profiles", "groups", "scenarios", "requirementIds", "nonClaimRefs",
  "replacementRequirementIds", "evidenceRefs", "sharedPremises", "members",
  "parameters", "preconditions", "actionSequence", "expectedObservations",
  "forbiddenObservations", "examples", "vocabularyRefs",
]);
const candidates = [
  "json-compact-v1",
  "json-hybrid-v1",
  "json-pretty-v1",
  "yaml-strict-v1",
  "toml-tristate-v1",
  "proofkit-source-text-v1",
];

const root = process.argv[2] ?? "out";
const manifestPath = process.argv[3] ?? "screen-manifest.v1.json";
const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
const index = JSON.parse(readFileSync(join(root, "fixture-index.v1.json"), "utf8"));
const renderedRoot = join(root, "rendered");
rmSync(renderedRoot, { recursive: true, force: true });

const allPaths = new Set();
for (const fixture of index.fixtures) allPaths.add(fixture.path);
for (const edit of index.edits) {
  allPaths.add(edit.beforePath);
  allPaths.add(edit.afterPath);
}

const rendered = new Map();
for (const relativePath of [...allPaths].sort()) {
  const semantic = JSON.parse(readFileSync(join(root, relativePath), "utf8"));
  const value = normalize(semantic);
  for (const candidate of candidates) {
    const payload = render(candidate, value);
    const outputPath = join(renderedRoot, candidate, relativePath.replace(/\.semantic\.json$/, ".source"));
    mkdirSync(dirname(outputPath), { recursive: true });
    writeFileSync(outputPath, payload, { encoding: "utf8", mode: 0o644 });
    rendered.set(`${candidate}:${relativePath}`, { path: outputPath, payload });
  }
}

const assignment = JSON.parse(readFileSync("review-assignment.v1.json", "utf8"));
const completeSemantic = JSON.parse(readFileSync(join(root, "selection", "complete.semantic.json"), "utf8"));
const duplicateValue = normalize(structuredClone(completeSemantic));
const requestGroup = duplicateValue.groups.find((group) => group.groupId === "RGRP-MODEL-REQUESTS");
requestGroup.members.push(structuredClone(requestGroup.members[0]));
for (const slot of assignment.slots) {
  const reviewRoot = join(root, "review", slot.slotId);
  rmSync(reviewRoot, { recursive: true, force: true });
  mkdirSync(reviewRoot, { recursive: true });
  const files = [
    ["task-1-complete.source", rendered.get(`${slot.candidateId}:selection/complete.semantic.json`).payload],
    ["task-2-repetition.source", rendered.get(`${slot.candidateId}:selection/repetition.semantic.json`).payload],
    ["task-3-unicode.source", rendered.get(`${slot.candidateId}:selection/unicode.semantic.json`).payload],
    ["task-4-duplicate.source", render(slot.candidateId, duplicateValue)],
  ];
  for (const [name, payload] of files) writeFileSync(join(reviewRoot, name), payload, { encoding: "utf8", mode: 0o444 });
  const before = rendered.get(`${slot.candidateId}:selection/edits/supersede.before.semantic.json`).path;
  const after = rendered.get(`${slot.candidateId}:selection/edits/supersede.after.semantic.json`).path;
  writeFileSync(join(reviewRoot, "task-5-supersede.diff"), diffText(before, after), { encoding: "utf8", mode: 0o444 });
}

const observations = {
  schemaVersion: manifest.schemaVersion,
  kind: "proofkit.requirement-source-codec-screen-observations",
  screenManifestSha256: sha256(readFileSync(manifestPath)),
  rendererSha256: sha256(readFileSync(new URL(import.meta.url))),
  candidates: [],
};

for (const candidate of candidates) {
  let weightedBytes = 0;
  const fixtureBytes = [];
  for (const fixture of index.fixtures) {
    const value = rendered.get(`${candidate}:${fixture.path}`);
    const bytes = Buffer.byteLength(value.payload);
    weightedBytes += bytes * fixture.weight;
    fixtureBytes.push({ fixtureId: fixture.id, bytes, weight: fixture.weight, sha256: sha256(value.payload) });
  }
  let changedLines = 0;
  let changedBytes = 0;
  let editLocality = true;
  const edits = [];
  for (const edit of index.edits) {
    const before = rendered.get(`${candidate}:${edit.beforePath}`).path;
    const after = rendered.get(`${candidate}:${edit.afterPath}`).path;
    const delta = diffMetrics(before, after);
    changedLines += delta.changedLines;
    changedBytes += delta.changedBytes;
    const localityViolations = editLocalityViolations(edit, delta.output);
    if (localityViolations.length > 0) editLocality = false;
    edits.push({ editId: edit.id, class: edit.class, changedLines: delta.changedLines, changedBytes: delta.changedBytes, localityViolations });
  }
  observations.candidates.push({
    candidateId: candidate,
    weightedCanonicalBytes: weightedBytes,
    fixtureBytes,
    changedLines,
    changedBytes,
    editLocality,
    edits,
    tokensO200kBase: null,
    reviewAccuracyBasisPoints: null,
    invalidMutationFalseAccepts: null,
    projectedProduction: projectedProduction(candidate),
  });
}
observations.candidates.sort((left, right) => left.candidateId.localeCompare(right.candidateId));
writeFileSync(join(root, `screen-observations.partial.v${manifest.schemaVersion}.json`), `${JSON.stringify(observations, null, 2)}\n`);

function normalize(value, key = "") {
  if (Array.isArray(value)) return value.map((item) => normalize(item));
  if (value === null) return collectionKeys.has(key) ? [] : null;
  if (typeof value !== "object") return value;
  const entries = Object.entries(value);
  if (entries.length === 2 && Object.hasOwn(value, "Present") && Object.hasOwn(value, "Value")) {
    if (value.Present !== true) return OMIT;
    return normalize(value.Value, key);
  }
  const result = {};
  for (const [rawKey, rawValue] of entries) {
    const normalizedKey = lowerFirst(rawKey);
    const normalizedValue = normalize(rawValue, normalizedKey);
    if (normalizedValue !== OMIT) result[normalizedKey] = normalizedValue;
  }
  return result;
}

function lowerFirst(value) {
  const normalized = value
    .replace(/^SHA256$/, "Sha256")
    .replace(/OID$/, "Oid")
    .replace(/IDs$/, "Ids")
    .replace(/ID$/, "Id");
  return normalized.length === 0 ? normalized : normalized[0].toLowerCase() + normalized.slice(1);
}

function render(candidate, value) {
  switch (candidate) {
    case "json-compact-v1": return `${JSON.stringify(value)}\n`;
    case "json-hybrid-v1": return renderHybrid(value);
    case "json-pretty-v1": return `${JSON.stringify(value, null, 2)}\n`;
    case "yaml-strict-v1": return `${renderYAML(value, 0)}\n`;
    case "toml-tristate-v1": return `${renderTOML(value)}\n`;
    case "proofkit-source-text-v1": return `${renderBlock(value, 0, true)}\n`;
    default: throw new Error(`unknown candidate ${candidate}`);
  }
}

function renderHybrid(value) {
	return `${hybridValueLines(value, 0, true).join("\n")}\n`;
}

function hybridValueLines(value, depth, forceObjectMultiline = false) {
	const indent = "  ".repeat(depth);
	if (Array.isArray(value)) {
		if (value.length === 0 || value.every(isScalar)) return [`${indent}${JSON.stringify(value)}`];
		const lines = [`${indent}[`];
		value.forEach((item, index) => {
			const itemLines = hybridValueLines(item, depth + 1);
			if (index > 0) itemLines[0] = `${"  ".repeat(depth)}, ${itemLines[0].trimStart()}`;
			lines.push(...itemLines);
		});
		lines.push(`${indent}]`);
		return lines;
	}
	if (value !== null && typeof value === "object") {
		const entries = Object.entries(value);
		const hasObjectArray = entries.some(([, item]) => Array.isArray(item) && item.some((entry) => entry !== null && typeof entry === "object"));
		if (!forceObjectMultiline && !hasObjectArray) return [`${indent}${JSON.stringify(value)}`];
		const lines = [`${indent}{`];
		entries.forEach(([key, item], index) => {
			const suffix = index + 1 === entries.length ? "" : ",";
			if (Array.isArray(item) && item.some((entry) => entry !== null && typeof entry === "object")) {
				const itemLines = hybridValueLines(item, depth + 1);
				lines.push(`${"  ".repeat(depth + 1)}${JSON.stringify(key)}: ${itemLines[0].trimStart()}`);
				lines.push(...itemLines.slice(1, -1));
				lines.push(`${itemLines.at(-1)}${suffix}`);
			} else {
				lines.push(`${"  ".repeat(depth + 1)}${JSON.stringify(key)}: ${JSON.stringify(item)}${suffix}`);
			}
		});
		lines.push(`${indent}}`);
		return lines;
	}
	return [`${indent}${JSON.stringify(value)}`];
}

function renderYAML(value, depth) {
  if (Array.isArray(value)) {
    if (value.length === 0) return `${"  ".repeat(depth)}[]`;
    return value.map((item) => {
      const prefix = `${"  ".repeat(depth)}-`;
      if (isScalar(item)) return `${prefix} ${yamlScalar(item)}`;
      const nested = renderYAML(item, depth + 1).split("\n");
      return `${prefix}\n${nested.join("\n")}`;
    }).join("\n");
  }
  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value);
    if (entries.length === 0) return `${"  ".repeat(depth)}{}`;
    return entries.map(([key, item]) => {
      const prefix = `${"  ".repeat(depth)}${key}:`;
      if (isScalar(item)) return `${prefix} ${yamlScalar(item)}`;
      if (Array.isArray(item) && item.length === 0) return `${prefix} []`;
      if (!Array.isArray(item) && Object.keys(item).length === 0) return `${prefix} {}`;
      return `${prefix}\n${renderYAML(item, depth + 1)}`;
    }).join("\n");
  }
  return `${"  ".repeat(depth)}${yamlScalar(value)}`;
}

function yamlScalar(value) {
  if (typeof value === "string") return JSON.stringify(value);
  if (value === null) return "null";
  return String(value);
}

function renderTOML(value) {
  const lines = [];
  emitTOMLTable(lines, value, [], false, false);
  while (lines.at(-1) === "") lines.pop();
  return lines.join("\n");
}

function emitTOMLTable(lines, value, path, arrayItem, emitHeader) {
  if (emitHeader) {
    if (lines.length > 0 && lines.at(-1) !== "") lines.push("");
    const name = path.map(tomlKey).join(".");
    lines.push(arrayItem ? `[[${name}]]` : `[${name}]`);
  }
  const nested = [];
  for (const [key, item] of Object.entries(value)) {
    if (isTOMLScalar(item) || isScalarArray(item) || item === null) {
      lines.push(`${tomlKey(key)} = ${tomlValue(item)}`);
    } else {
      nested.push([key, item]);
    }
  }
  for (const [key, item] of nested) {
    if (Array.isArray(item)) {
      if (item.length === 0) {
        lines.push(`${tomlKey(key)} = []`);
        continue;
      }
      for (const entry of item) emitTOMLTable(lines, entry, [...path, key], true, true);
    } else {
      emitTOMLTable(lines, item, [...path, key], false, true);
    }
  }
}

function tomlKey(value) {
  return /^[A-Za-z0-9_-]+$/.test(value) ? value : JSON.stringify(value);
}

function tomlValue(value) {
  if (value === null) return `{ state = "null" }`;
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean" || typeof value === "number") return String(value);
  if (Array.isArray(value)) return `[${value.map(tomlValue).join(", ")}]`;
  throw new Error("unsupported TOML scalar");
}

function renderBlock(value, depth, root = false) {
  const indent = "  ".repeat(depth);
  if (Array.isArray(value)) {
    if (value.length === 0) return "[]";
    if (value.every(isScalar)) return `[${value.map(blockScalar).join(" ")}]`;
    return `{\n${value.map((item) => `${"  ".repeat(depth + 1)}item ${renderBlock(item, depth + 1)}`).join("\n")}\n${indent}}`;
  }
  if (value !== null && typeof value === "object") {
    const entries = Object.entries(value);
    const body = entries.map(([key, item]) => {
      const rendered = isScalar(item) ? blockScalar(item) : renderBlock(item, depth + 1);
      return `${"  ".repeat(depth + (root ? 0 : 1))}${key} ${rendered}`;
    }).join("\n");
    if (root) return `source {\n${body}\n}`;
    return `{\n${body}\n${indent}}`;
  }
  return blockScalar(value);
}

function blockScalar(value) {
  if (typeof value === "string") return JSON.stringify(value);
  if (value === null) return "null";
  return String(value);
}

function isScalar(value) {
  return value === null || typeof value !== "object";
}

function isTOMLScalar(value) {
  return typeof value === "string" || typeof value === "number" || typeof value === "boolean";
}

function isScalarArray(value) {
  return Array.isArray(value) && value.every((item) => isTOMLScalar(item));
}

function diffMetrics(before, after) {
  const output = diffText(before, after);
  let changedLines = 0;
  let changedBytes = 0;
  for (const line of output.split("\n")) {
    if ((line.startsWith("+") && !line.startsWith("+++")) || (line.startsWith("-") && !line.startsWith("---"))) {
      changedLines += 1;
      changedBytes += Buffer.byteLength(line.slice(1)) + 1;
    }
  }
  return { changedLines, changedBytes, output };
}

function editLocalityViolations(edit, diff) {
  const affected = {
    "add": new Set(["REQ-MODEL-005", "RGRP-MODEL-REQUESTS"]),
    "modify": new Set(["REQ-MODEL-002"]),
    "move": new Set(["REQ-SCALE-0007", "RGRP-SCALE-01", "RGRP-SCALE-02"]),
    "split": new Set(["REQ-SCALE-0005", "REQ-SCALE-0007", "RGRP-SCALE-01", "RGRP-SCALE-SPLIT"]),
    "merge": new Set(["REQ-SCALE-0005", "REQ-SCALE-0007", "RGRP-SCALE-01", "RGRP-SCALE-SPLIT"]),
    "deprecate": new Set(["REQ-MODEL-001", "REQ-MODEL-004"]),
    "supersede": new Set(["REQ-MODEL-001", "REQ-MODEL-003"]),
    "scenario-example": new Set(["SCN-MODEL-REQUEST", "EX-MODEL-REQUEST-003"]),
  }[edit.id];
  if (!affected) throw new Error(`missing affected-entity set for ${edit.id}`);
  const stable = new Set();
  for (const relativePath of [edit.beforePath, edit.afterPath]) {
    const payload = readFileSync(join(root, relativePath), "utf8");
    for (const match of payload.matchAll(/\b(?:REQ|RGRP|SCN|EX)-[A-Z0-9-]+\b/g)) stable.add(match[0]);
  }
  const violations = new Set();
  for (const line of diff.split("\n")) {
    if (!((line.startsWith("+") && !line.startsWith("+++")) || (line.startsWith("-") && !line.startsWith("---")))) continue;
    for (const match of line.matchAll(/\b(?:REQ|RGRP|SCN|EX)-[A-Z0-9-]+\b/g)) {
      if (stable.has(match[0]) && !affected.has(match[0])) violations.add(match[0]);
    }
  }
  return [...violations].sort();
}

function diffText(before, after) {
  let output = "";
  try {
    output = execFileSync("git", ["diff", "--no-index", "--no-color", "--unified=0", "--", before, after], { encoding: "utf8" });
  } catch (error) {
    if (error.status !== 1) throw error;
    output = error.stdout;
  }
  return output;
}

function projectedProduction(candidate) {
  const rows = {
    "json-compact-v1": { loc: 520, branches: 44, basis: "closed DTO + bounded standard JSON scanner + source map" },
    "json-hybrid-v1": { loc: 535, branches: 46, basis: "closed DTO + bounded standard JSON scanner + source map" },
    "json-pretty-v1": { loc: 520, branches: 44, basis: "closed DTO + bounded standard JSON scanner + source map" },
    "yaml-strict-v1": { loc: 690, branches: 61, basis: "restricted YAML admission + closed DTO + source map" },
    "toml-tristate-v1": { loc: 720, branches: 65, basis: "TOML admission + tri-state adapter + closed DTO + source map" },
    "proofkit-source-text-v1": { loc: 910, branches: 92, basis: "owned scanner + parser + grammar diagnostics + closed DTO + source map" },
  };
  return rows[candidate];
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}
