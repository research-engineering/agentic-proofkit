import hashlib
import json
import pathlib
import sys

import tiktoken


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: token_count.py rendered-directory")
    root = pathlib.Path(sys.argv[1])
    encoder = tiktoken.get_encoding("o200k_base")
    records = []
    for path in sorted(root.glob("*/**/*.source")):
        payload = path.read_bytes()
        records.append(
            {
                "path": path.relative_to(root).as_posix(),
                "sha256": hashlib.sha256(payload).hexdigest(),
                "tokens": len(encoder.encode(payload.decode("utf-8"), disallowed_special=())),
            }
        )
    print(json.dumps({"implementation": "openai-tiktoken-0.14.0", "records": records}, sort_keys=True))


if __name__ == "__main__":
    main()
