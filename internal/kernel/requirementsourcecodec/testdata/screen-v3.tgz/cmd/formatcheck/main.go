package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/BurntSushi/toml"
	"go.yaml.in/yaml/v3"
)

func main() {
	if len(os.Args) != 2 {
		fatalf("usage: formatcheck rendered-directory")
	}
	checks := map[string]func([]byte) error{
		"json-compact-v1": checkJSON,
		"json-hybrid-v1":  checkJSON,
		"json-pretty-v1":  checkJSON,
		"toml-tristate-v1": func(payload []byte) error {
			var value map[string]any
			return toml.Unmarshal(payload, &value)
		},
		"yaml-strict-v1": func(payload []byte) error {
			var value yaml.Node
			return yaml.Unmarshal(payload, &value)
		},
	}
	for candidate, check := range checks {
		root := filepath.Join(os.Args[1], candidate)
		err := filepath.WalkDir(root, func(path string, entry os.DirEntry, walkErr error) error {
			if walkErr != nil {
				return walkErr
			}
			if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".source") {
				return nil
			}
			payload, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			if err := check(payload); err != nil {
				return fmt.Errorf("%s: %w", path, err)
			}
			return nil
		})
		if err != nil {
			fatalf("%s: %v", candidate, err)
		}
	}
}

func checkJSON(payload []byte) error {
	var value any
	if err := json.Unmarshal(payload, &value); err != nil {
		return err
	}
	return nil
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", args...)
	os.Exit(1)
}
