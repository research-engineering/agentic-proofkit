package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	m "github.com/research-engineering/agentic-proofkit/internal/kernel/requirementsourcemodel"
)

type sourceDocument struct {
	SchemaVersion       int                    `json:"schemaVersion"`
	Kind                string                 `json:"kind"`
	SourceID            string                 `json:"sourceId"`
	SpecPackagePath     string                 `json:"specPackagePath"`
	SourceNonClaimRefs  []string               `json:"sourceNonClaimRefs"`
	NonClaimDefinitions []m.NonClaimDefinition `json:"nonClaimDefinitions"`
	Vocabulary          []m.VocabularyTerm     `json:"vocabulary"`
	Derivations         []m.Derivation         `json:"derivations"`
	Profiles            []m.Profile            `json:"profiles"`
	Groups              []m.Group              `json:"groups"`
	Scenarios           []m.Scenario           `json:"scenarios"`
}

type fixtureRecord struct {
	ID             string `json:"id"`
	Stratum        string `json:"stratum"`
	Weight         int    `json:"weight"`
	Path           string `json:"path"`
	SemanticSHA256 string `json:"semanticSha256"`
}

type editRecord struct {
	ID           string `json:"id"`
	Class        string `json:"class"`
	BeforePath   string `json:"beforePath"`
	BeforeSHA256 string `json:"beforeSha256"`
	AfterPath    string `json:"afterPath"`
	AfterSHA256  string `json:"afterSha256"`
}

type fixtureIndex struct {
	SchemaVersion       int             `json:"schemaVersion"`
	Kind                string          `json:"kind"`
	SelectionSeedSHA256 string          `json:"selectionSeedSha256,omitempty"`
	Fixtures            []fixtureRecord `json:"fixtures"`
	Edits               []editRecord    `json:"edits"`
}

func main() {
	root := "out"
	var seed []byte
	if len(os.Args) >= 2 {
		root = os.Args[1]
	}
	if len(os.Args) == 3 {
		var err error
		seed, err = hex.DecodeString(os.Args[2])
		if err != nil || len(seed) != 32 {
			fatalf("selection seed must be exactly 32 bytes of lowercase hexadecimal")
		}
	} else if len(os.Args) > 3 {
		fatalf("usage: fixturegen [output-directory [selection-seed-hex]]")
	}
	if err := os.RemoveAll(root); err != nil {
		fatalf("remove output: %v", err)
	}
	if err := os.MkdirAll(filepath.Join(root, "selection"), 0o755); err != nil {
		fatalf("create output: %v", err)
	}

	repetitionCount := 24
	scenarioCount := 12
	exampleCount := 8
	scaleCount := 240
	if len(seed) > 0 {
		repetitionCount += int(seed[0]%17) + 1
		scenarioCount += int(seed[1]%7) + 1
		exampleCount += int(seed[2]%5) + 1
		scaleCount += int(seed[3]%97) + 1
	}
	fixtures := []struct {
		id      string
		stratum string
		weight  int
		draft   m.Draft
	}{
		{"complete", "complete_fields", 20, baseDraft()},
		{"repetition", "profile_and_stem_repetition", 25, repetitionDraft(repetitionCount)},
		{"scenarios", "scenario_and_example_heavy", 15, scenarioDraft(scenarioCount, exampleCount)},
		{"unicode", "lifecycle_derivation_unicode", 15, unicodeDraft()},
		{"scale", "repository_scale", 25, repetitionDraft(scaleCount)},
	}

	index := fixtureIndex{SchemaVersion: 1, Kind: "proofkit.requirement-source-codec-selection-fixtures"}
	if len(seed) > 0 {
		index.SelectionSeedSHA256 = digest(seed)
	}
	tag := ""
	if len(seed) > 0 {
		tag = hex.EncodeToString(seed[:4])
	}
	for _, fixture := range fixtures {
		path := filepath.Join("selection", fixture.id+".semantic.json")
		payload := documentBytes(tagDraft(fixture.draft, tag))
		write(filepath.Join(root, path), payload)
		index.Fixtures = append(index.Fixtures, fixtureRecord{
			ID: fixture.id, Stratum: fixture.stratum, Weight: fixture.weight,
			Path: filepath.ToSlash(path), SemanticSHA256: digest(payload),
		})
	}

	edits := selectionEdits()
	for _, edit := range edits {
		beforePath := filepath.Join("selection", "edits", edit.id+".before.semantic.json")
		afterPath := filepath.Join("selection", "edits", edit.id+".after.semantic.json")
		before := documentBytes(tagDraft(edit.before, tag))
		after := documentBytes(tagDraft(edit.after, tag))
		write(filepath.Join(root, beforePath), before)
		write(filepath.Join(root, afterPath), after)
		index.Edits = append(index.Edits, editRecord{
			ID: edit.id, Class: edit.class,
			BeforePath: filepath.ToSlash(beforePath), BeforeSHA256: digest(before),
			AfterPath: filepath.ToSlash(afterPath), AfterSHA256: digest(after),
		})
	}
	sort.Slice(index.Fixtures, func(i, j int) bool { return index.Fixtures[i].ID < index.Fixtures[j].ID })
	sort.Slice(index.Edits, func(i, j int) bool { return index.Edits[i].ID < index.Edits[j].ID })
	write(filepath.Join(root, "fixture-index.v1.json"), pretty(index))
}

func tagDraft(draft m.Draft, tag string) m.Draft {
	result := clone(draft)
	if tag == "" {
		return result
	}
	result.SourceID += "." + tag
	result.SpecPackagePath += "-" + tag
	result.NonClaimDefinitions[0].Statement += " Selection cohort " + tag + "."
	return result
}

type editFixture struct {
	id     string
	class  string
	before m.Draft
	after  m.Draft
}

func selectionEdits() []editFixture {
	addBefore := baseDraft()
	addAfter := clone(addBefore)
	addAfter.Groups[0].Members = append(addAfter.Groups[0].Members, m.Member{
		RequirementID: "REQ-MODEL-005", StatementCompletion: "bound retry attempts.", Fields: memberFields(),
	})

	modifyBefore := baseDraft()
	modifyAfter := clone(modifyBefore)
	modifyAfter.Groups[0].Members[1].StatementCompletion = "reject every malformed request deterministically."

	moveBefore := repetitionDraft(8)
	moveAfter := clone(moveBefore)
	moved := moveAfter.Groups[0].Members[len(moveAfter.Groups[0].Members)-1]
	moveAfter.Groups[0].Members = moveAfter.Groups[0].Members[:len(moveAfter.Groups[0].Members)-1]
	moveAfter.Groups[1].Members = append(moveAfter.Groups[1].Members, moved)

	splitBefore := repetitionDraft(8)
	splitAfter := clone(splitBefore)
	splitAfter.Groups = append(splitAfter.Groups, m.Group{
		GroupID: "RGRP-SCALE-SPLIT", ProfileID: "RPROF-MODEL-BLOCKING",
		StatementStem:  splitAfter.Groups[0].StatementStem,
		SharedPremises: append([]string(nil), splitAfter.Groups[0].SharedPremises...),
		Members:        append([]m.Member(nil), splitAfter.Groups[0].Members[2:]...),
	})
	splitAfter.Groups[0].Members = splitAfter.Groups[0].Members[:2]

	mergeBefore := clone(splitAfter)
	mergeAfter := clone(splitBefore)

	deprecateBefore := baseDraft()
	deprecateAfter := clone(deprecateBefore)
	deprecateAfter.Groups[2].Members[0].Fields.Lifecycle.Value = m.Lifecycle{
		State: m.LifecycleDeprecated, EvidenceRefs: []string{"docs/evidence/deprecated.md"},
	}

	supersedeBefore := baseDraft()
	supersedeAfter := clone(supersedeBefore)
	supersedeAfter.Groups[1].Members[0].Fields.ClaimLevel.Value = m.ClaimAdvisory
	supersedeAfter.Groups[1].Members[0].Fields.Lifecycle.Value = m.Lifecycle{
		State:                     m.LifecycleSuperseded,
		ReplacementRequirementIDs: []string{"REQ-MODEL-001"},
		EvidenceRefs:              []string{"docs/evidence/superseded-deferred.md"},
	}
	supersedeAfter.Groups[1].Members[0].Fields.Deferral.Value = nil

	scenarioBefore := baseDraft()
	scenarioAfter := clone(scenarioBefore)
	scenarioAfter.Scenarios[0].Examples = append(scenarioAfter.Scenarios[0].Examples,
		m.Example{ExampleID: "EX-MODEL-REQUEST-003", Values: map[string]m.ScenarioValue{"surface": "tertiary"}})

	return []editFixture{
		{"add", "add", addBefore, addAfter},
		{"modify", "modify", modifyBefore, modifyAfter},
		{"move", "move", moveBefore, moveAfter},
		{"split", "split", splitBefore, splitAfter},
		{"merge", "merge", mergeBefore, mergeAfter},
		{"deprecate", "deprecate", deprecateBefore, deprecateAfter},
		{"supersede", "supersede", supersedeBefore, supersedeAfter},
		{"scenario-example", "scenario_example", scenarioBefore, scenarioAfter},
	}
}

func documentBytes(draft m.Draft) []byte {
	model, err := m.NormalizeWithLimits(draft, m.DefaultLimits())
	if err != nil {
		fatalf("normalize fixture: %v", err)
	}
	atomic := model.Atomic()
	layout := model.Layout()
	references := model.References()
	return pretty(sourceDocument{
		SchemaVersion:       2,
		Kind:                "proofkit.requirement-source",
		SourceID:            atomic.SourceID,
		SpecPackagePath:     atomic.SpecPackagePath,
		SourceNonClaimRefs:  atomic.SourceNonClaimRefs,
		NonClaimDefinitions: atomic.NonClaimDefinitions,
		Vocabulary:          atomic.Vocabulary,
		Derivations:         references.Derivations,
		Profiles:            layout.Profiles,
		Groups:              layout.Groups,
		Scenarios:           atomic.Scenarios,
	})
}

func baseDraft() m.Draft {
	active := m.Lifecycle{State: m.LifecycleActive}
	deferral := &m.Deferral{
		OwnerID: "proofkit.model", RiskAcceptedBy: "proofkit.owner",
		ReviewCondition: "Review after the model experiment.", ExpiryRef: "proofkit.model.expiry",
		MergePolicy: "proofkit.model.merge", EvidenceRefs: []string{"docs/evidence/deferral.md"},
	}
	return m.Draft{
		SourceID: "proofkit.model.source", SpecPackagePath: "docs/specs/proofkit-model",
		SourceNonClaimRefs: []string{"NCL-MODEL-001"},
		NonClaimDefinitions: []m.NonClaimDefinition{
			{NonClaimID: "NCL-MODEL-001", Statement: "The model does not prove implementation correctness."},
			{NonClaimID: "NCL-MODEL-002", Statement: "A declared requirement does not prove its own satisfaction."},
			{NonClaimID: "NCL-MODEL-003", Statement: "Scenario examples are not exhaustive proof."},
			{NonClaimID: "NCL-MODEL-004", Statement: "Derivation provenance does not prove requirement correctness."},
		},
		Vocabulary: []m.VocabularyTerm{{TermID: "TERM-MODEL-SERVICE", Kind: m.TermSubject, Label: "service", Definition: "The bounded service under specification."}},
		Derivations: []m.Derivation{{
			DerivationID: "DRV-MODEL-001", SourceKind: m.SourceOwnerDecision,
			SourceRef: m.GitBlobRef{ObjectFormat: m.ObjectSHA1, CommitOID: "0123456789abcdef0123456789abcdef01234567", Path: "docs/decisions/model.md", SHA256: "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"},
			Selector:  m.ByteRange{Start: 0, End: 64}, RequirementIDs: []string{"REQ-MODEL-001", "REQ-MODEL-002"}, NonClaimRefs: []string{"NCL-MODEL-004"},
		}},
		Profiles: []m.Profile{{ProfileID: "RPROF-MODEL-BLOCKING", Fields: blockingProfileFields()}},
		Groups: []m.Group{
			{GroupID: "RGRP-MODEL-REQUESTS", ProfileID: "RPROF-MODEL-BLOCKING", StatementStem: "The service must", SharedPremises: []string{"The service is available."}, Members: []m.Member{
				{RequirementID: "REQ-MODEL-001", StatementCompletion: "accept requests.", Fields: memberFields()},
				{RequirementID: "REQ-MODEL-002", StatementCompletion: "reject malformed requests.", Fields: memberFields()},
			}},
			{GroupID: "RGRP-MODEL-DEFERRED", Members: []m.Member{{RequirementID: "REQ-MODEL-003", StatementCompletion: "Deferred behavior remains owner-reviewed.", Fields: fullFields(m.ClaimDeferred, active, deferral)}}},
			{GroupID: "RGRP-MODEL-SUPERSEDED", Members: []m.Member{{RequirementID: "REQ-MODEL-004", StatementCompletion: "Historical behavior is superseded.", Fields: fullFields(m.ClaimAdvisory, m.Lifecycle{State: m.LifecycleSuperseded, ReplacementRequirementIDs: []string{"REQ-MODEL-001"}, EvidenceRefs: []string{"docs/evidence/superseded.md"}}, nil)}}},
		},
		Scenarios: []m.Scenario{{
			ScenarioID: "SCN-MODEL-REQUEST", RequirementIDs: []string{"REQ-MODEL-001"}, Parameters: []string{"surface"},
			Preconditions: []string{"The ${surface} surface is available."}, ActionSequence: []string{"Submit a request.", "Wait for the response."},
			ExpectedObservations: []string{"The request is accepted."}, ForbiddenObservations: []string{"The service exposes a secret."},
			Examples:       []m.Example{{ExampleID: "EX-MODEL-REQUEST-001", Values: map[string]m.ScenarioValue{"surface": "primary"}}, {ExampleID: "EX-MODEL-REQUEST-002", Values: map[string]m.ScenarioValue{"surface": "secondary"}}},
			VocabularyRefs: []string{"TERM-MODEL-SERVICE"}, NonClaimRefs: []string{"NCL-MODEL-003"},
		}},
	}
}

func repetitionDraft(count int) m.Draft {
	draft := baseDraft()
	draft.Groups = draft.Groups[:0]
	for groupIndex := 0; groupIndex < 2; groupIndex++ {
		group := m.Group{
			GroupID: fmt.Sprintf("RGRP-SCALE-%02d", groupIndex+1), ProfileID: "RPROF-MODEL-BLOCKING",
			StatementStem: "The proof workflow must", SharedPremises: []string{"The admitted source is immutable."},
		}
		for memberIndex := groupIndex; memberIndex < count; memberIndex += 2 {
			group.Members = append(group.Members, m.Member{
				RequirementID:       fmt.Sprintf("REQ-SCALE-%04d", memberIndex+1),
				StatementCompletion: fmt.Sprintf("preserve invariant number %d.", memberIndex+1), Fields: memberFields(),
			})
		}
		draft.Groups = append(draft.Groups, group)
	}
	draft.Derivations = nil
	draft.Scenarios = nil
	draft.Vocabulary = nil
	draft.NonClaimDefinitions = draft.NonClaimDefinitions[:2]
	draft.SourceNonClaimRefs = []string{"NCL-MODEL-001"}
	return draft
}

func scenarioDraft(scenarios, examples int) m.Draft {
	draft := baseDraft()
	base := draft.Scenarios[0]
	draft.Scenarios = nil
	for scenarioIndex := 0; scenarioIndex < scenarios; scenarioIndex++ {
		scenario := base
		scenario.ScenarioID = fmt.Sprintf("SCN-MODEL-%03d", scenarioIndex+1)
		scenario.Examples = nil
		for exampleIndex := 0; exampleIndex < examples; exampleIndex++ {
			scenario.Examples = append(scenario.Examples, m.Example{
				ExampleID: fmt.Sprintf("EX-MODEL-%03d-%03d", scenarioIndex+1, exampleIndex+1),
				Values:    map[string]m.ScenarioValue{"surface": m.ScenarioValue(fmt.Sprintf("surface-%03d", exampleIndex+1))},
			})
		}
		draft.Scenarios = append(draft.Scenarios, scenario)
	}
	return draft
}

func unicodeDraft() m.Draft {
	draft := baseDraft()
	draft.Groups[0].StatementStem = "The café service must"
	draft.Groups[0].Members[0].StatementCompletion = "preserve Καλημέρα and 日本語 exactly."
	draft.Scenarios[0].ExpectedObservations = []string{"The response contains 👩‍💻 without normalization."}
	return draft
}

func blockingProfileFields() m.MetadataFields {
	return m.MetadataFields{
		OwnerID: m.Own("proofkit.model"), ClaimLevel: m.Own(m.ClaimBlocking), RiskClass: m.Own(m.RiskHigh),
		UpdatePolicy: m.Own(m.UpdatePolicy{ReviewOwnerID: "proofkit.model", RequiresImpactDeclaration: true, RequiresProofBindingReview: true}),
	}
}

func memberFields() m.MetadataFields {
	return m.MetadataFields{
		NonClaimRefs: m.Own([]string{"NCL-MODEL-002"}), Lifecycle: m.Own(m.Lifecycle{State: m.LifecycleActive}), Deferral: m.Own[*m.Deferral](nil),
	}
}

func fullFields(claim m.ClaimLevel, lifecycle m.Lifecycle, deferral *m.Deferral) m.MetadataFields {
	return m.MetadataFields{
		OwnerID: m.Own("proofkit.model"), ClaimLevel: m.Own(claim), RiskClass: m.Own(m.RiskMedium),
		NonClaimRefs: m.Own([]string{"NCL-MODEL-002"}), Lifecycle: m.Own(lifecycle), Deferral: m.Own(deferral),
		UpdatePolicy: m.Own(m.UpdatePolicy{ReviewOwnerID: "proofkit.model", RequiresImpactDeclaration: true, RequiresProofBindingReview: true}),
	}
}

func clone(value m.Draft) m.Draft {
	payload, err := json.Marshal(value)
	if err != nil {
		fatalf("clone marshal: %v", err)
	}
	var result m.Draft
	if err := json.Unmarshal(payload, &result); err != nil {
		fatalf("clone unmarshal: %v", err)
	}
	return result
}

func pretty(value any) []byte {
	payload, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		fatalf("marshal: %v", err)
	}
	return append(payload, '\n')
}

func digest(payload []byte) string {
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:])
}

func write(path string, payload []byte) {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		fatalf("create parent: %v", err)
	}
	if err := os.WriteFile(path, payload, 0o644); err != nil {
		fatalf("write %s: %v", path, err)
	}
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", args...)
	os.Exit(1)
}
