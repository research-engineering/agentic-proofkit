package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/tiktoken-go/tokenizer"
)

type record struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Tokens int    `json:"tokens"`
}

type report struct {
	Implementation string   `json:"implementation"`
	Records        []record `json:"records"`
}

func main() {
	if len(os.Args) != 2 {
		fatalf("usage: tokengo rendered-directory")
	}
	codec, err := tokenizer.Get(tokenizer.O200kBase)
	if err != nil {
		fatalf("load tokenizer: %v", err)
	}
	root := os.Args[1]
	var records []record
	err = filepath.WalkDir(root, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".source") {
			return nil
		}
		payload, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		ids, _, err := codec.Encode(string(payload))
		if err != nil {
			return err
		}
		sum := sha256.Sum256(payload)
		relative, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		records = append(records, record{
			Path: filepath.ToSlash(relative), SHA256: hex.EncodeToString(sum[:]), Tokens: len(ids),
		})
		return nil
	})
	if err != nil {
		fatalf("walk rendered files: %v", err)
	}
	sort.Slice(records, func(i, j int) bool { return records[i].Path < records[j].Path })
	payload, err := json.Marshal(report{Implementation: "tiktoken-go-0.8.1", Records: records})
	if err != nil {
		fatalf("marshal report: %v", err)
	}
	fmt.Println(string(payload))
}

func fatalf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", args...)
	os.Exit(1)
}
