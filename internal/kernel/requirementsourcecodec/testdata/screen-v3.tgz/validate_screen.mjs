import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const OMIT = Symbol("omit");
const collections = new Set([
  "sourceNonClaimRefs", "nonClaimDefinitions", "vocabulary", "derivations", "profiles", "groups", "scenarios",
  "requirementIds", "nonClaimRefs", "replacementRequirementIds", "evidenceRefs", "sharedPremises", "members",
  "parameters", "preconditions", "actionSequence", "expectedObservations", "forbiddenObservations", "examples", "vocabularyRefs",
]);

if (process.argv.length !== 4) throw new Error("usage: node validate_screen.mjs output-directory manifest");
const [, , root, manifestPath] = process.argv;
const manifestBytes = readFileSync(manifestPath);
const manifest = JSON.parse(manifestBytes);
const opening = readJSON(join(root, `selection-opening.v${manifest.schemaVersion}.json`));
const indexBytes = readFileSync(join(root, "fixture-index.v1.json"));
const index = JSON.parse(indexBytes);
const observationPath = join(root, `screen-observations.partial.v${manifest.schemaVersion}.json`);
const observations = readJSON(observationPath);

assert.equal(opening.manifestSha256, sha256(manifestBytes));
assert.equal(opening.fixtureIndexSha256, sha256(indexBytes));
assert.equal(opening.generatorSha256, manifest.fixtureGenerator.sha256);
assert.equal(opening.rendererSha256, manifest.renderer.sha256);
assert.equal(sha256(readFileSync(manifest.fixtureGenerator.path)), manifest.fixtureGenerator.sha256);
assert.equal(sha256(readFileSync(manifest.renderer.path)), manifest.renderer.sha256);
assert.equal(observations.screenManifestSha256, opening.manifestSha256);
assert.equal(observations.rendererSha256, opening.rendererSha256);

execFileSync("go", ["run", "./cmd/formatcheck", join(root, "rendered")], { stdio: "inherit" });

const validation = {
  schemaVersion: manifest.schemaVersion,
  kind: "proofkit.requirement-source-codec-screen-validation",
  manifestSha256: opening.manifestSha256,
  fixtureIndexSha256: opening.fixtureIndexSha256,
  observationSha256: sha256(readFileSync(observationPath)),
  candidates: [],
};

for (const candidate of observations.candidates) {
  let weightedCanonicalBytes = 0;
  let changedLines = 0;
  let changedBytes = 0;
  let editLocality = true;
  const fixtureRows = [];
  const editRows = [];
  for (const fixture of index.fixtures) {
    const path = renderedPath(candidate.candidateId, fixture.path);
    const payload = readFileSync(path);
    const bytes = payload.length;
    weightedCanonicalBytes += bytes * fixture.weight;
    fixtureRows.push({ fixtureId: fixture.id, bytes, sha256: sha256(payload) });
    if (candidate.candidateId.startsWith("json-")) {
      const expected = normalizeSemantic(readJSON(join(root, fixture.path)));
      const actual = JSON.parse(payload.toString("utf8"));
      assert.deepEqual(actual, expected, `${candidate.candidateId}/${fixture.id} is not field-complete`);
    }
  }
  for (const edit of index.edits) {
    const before = renderedPath(candidate.candidateId, edit.beforePath);
    const after = renderedPath(candidate.candidateId, edit.afterPath);
    const delta = independentDiff(before, after);
    const violations = localityViolations(edit.id, delta.output, manifest.editLocality.affectedEntitySets);
    changedLines += delta.changedLines;
    changedBytes += delta.changedBytes;
    if (violations.length > 0) editLocality = false;
    editRows.push({ editId: edit.id, changedLines: delta.changedLines, changedBytes: delta.changedBytes, localityViolations: violations });
  }
  const producer = observations.candidates.find((row) => row.candidateId === candidate.candidateId);
  assert.equal(producer.weightedCanonicalBytes, weightedCanonicalBytes);
  assert.equal(producer.changedLines, changedLines);
  assert.equal(producer.changedBytes, changedBytes);
  assert.equal(producer.editLocality, editLocality);
  validation.candidates.push({
    candidateId: candidate.candidateId,
    weightedCanonicalBytes,
    changedLines,
    changedBytes,
    editLocality,
    jsonFieldClosure: candidate.candidateId.startsWith("json-") ? "passed" : "not_applicable",
    fixtureRows,
    editRows,
  });
}
validation.candidates.sort((left, right) => left.candidateId.localeCompare(right.candidateId));
writeFileSync(join(root, `screen-validation.v${manifest.schemaVersion}.json`), `${JSON.stringify(validation, null, 2)}\n`, { mode: 0o444 });

function renderedPath(candidateId, semanticPath) {
  return join(root, "rendered", candidateId, semanticPath.replace(/\.semantic\.json$/, ".source"));
}

function normalizeSemantic(value, key = "") {
  if (Array.isArray(value)) return value.map((item) => normalizeSemantic(item));
  if (value === null) return collections.has(key) ? [] : null;
  if (typeof value !== "object") return value;
  if (Object.keys(value).length === 2 && Object.hasOwn(value, "Present") && Object.hasOwn(value, "Value")) {
    if (value.Present !== true) return OMIT;
    return normalizeSemantic(value.Value, key);
  }
  const result = {};
  for (const [rawKey, rawValue] of Object.entries(value)) {
    const normalizedKey = keyName(rawKey);
    const normalizedValue = normalizeSemantic(rawValue, normalizedKey);
    if (normalizedValue !== OMIT) result[normalizedKey] = normalizedValue;
  }
  return result;
}

function keyName(value) {
  const normalized = value.replace(/^SHA256$/, "Sha256").replace(/OID$/, "Oid").replace(/IDs$/, "Ids").replace(/ID$/, "Id");
  return normalized.length === 0 ? normalized : normalized[0].toLowerCase() + normalized.slice(1);
}

function independentDiff(before, after) {
  let output;
  try {
    output = execFileSync("git", ["diff", "--no-index", "--no-color", "--unified=0", "--", before, after], { encoding: "utf8" });
  } catch (error) {
    if (error.status !== 1) throw error;
    output = error.stdout;
  }
  let changedLines = 0;
  let changedBytes = 0;
  for (const line of output.split("\n")) {
    if ((line.startsWith("+") && !line.startsWith("+++")) || (line.startsWith("-") && !line.startsWith("---"))) {
      changedLines += 1;
      changedBytes += Buffer.byteLength(line.slice(1)) + 1;
    }
  }
  return { output, changedLines, changedBytes };
}

function localityViolations(editId, diff, affectedSets) {
  const affected = new Set(affectedSets[editId]);
  const violations = new Set();
  for (const line of diff.split("\n")) {
    if (!((line.startsWith("+") && !line.startsWith("+++")) || (line.startsWith("-") && !line.startsWith("---")))) continue;
    for (const match of line.matchAll(/\b(?:REQ|RGRP|SCN|EX)-[A-Z0-9-]+\b/g)) {
      if (!affected.has(match[0])) violations.add(match[0]);
    }
  }
  return [...violations].sort();
}

function readJSON(path) {
  return JSON.parse(readFileSync(path, "utf8"));
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}
