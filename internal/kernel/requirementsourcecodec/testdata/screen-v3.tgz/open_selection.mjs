import { createHash, randomBytes } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

if (process.argv.length !== 4) {
  throw new Error("usage: node open_selection.mjs manifest output-directory");
}
const [, , manifestPath, outputRoot] = process.argv;
const manifestBytes = readFileSync(manifestPath);
const manifest = JSON.parse(manifestBytes);
verifyBoundFile(manifest.fixtureGenerator);
verifyBoundFile(manifest.renderer);
verifyBoundFile(manifest.selectionOpener);
for (const binding of manifest.methodBindings ?? []) verifyBoundFile(binding);
if (manifest.review?.assignment) verifyBoundFile(manifest.review.assignment);

const seed = randomBytes(manifest.selectionOpeningProtocol.seedBytes);
execFileSync("go", ["run", "./cmd/fixturegen", outputRoot, seed.toString("hex")], { stdio: "inherit" });
const indexPath = join(outputRoot, "fixture-index.v1.json");
const indexBytes = readFileSync(indexPath);
const index = JSON.parse(indexBytes);
const seedSha256 = sha256(seed);
if (index.selectionSeedSha256 !== seedSha256) throw new Error("fixture index does not bind the opened seed");

const receipt = {
  schemaVersion: manifest.schemaVersion,
  kind: "proofkit.requirement-source-codec-selection-opening",
  manifestSha256: sha256(manifestBytes),
  generatorSha256: manifest.fixtureGenerator.sha256,
  rendererSha256: manifest.renderer.sha256,
  selectionSeedSha256: seedSha256,
  selectionSeedReveal: seed.toString("hex"),
  fixtureIndexSha256: sha256(indexBytes),
  fixtureIndexPath: "fixture-index.v1.json",
  state: "opened_once",
};
mkdirSync(outputRoot, { recursive: true });
writeFileSync(join(outputRoot, `selection-opening.v${manifest.schemaVersion}.json`), `${JSON.stringify(receipt, null, 2)}\n`, { mode: 0o444 });

function verifyBoundFile(binding) {
  const actual = sha256(readFileSync(binding.path));
  if (actual !== binding.sha256) throw new Error(`${binding.path} digest mismatch`);
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}
