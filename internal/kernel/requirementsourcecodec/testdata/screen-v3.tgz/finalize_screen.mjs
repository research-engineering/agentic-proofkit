import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

if (process.argv.length !== 5) throw new Error("usage: node finalize_screen.mjs output-directory manifest review-results");
const [, , root, manifestPath, reviewResultsPath] = process.argv;
const manifestBytes = readFileSync(manifestPath);
const manifest = JSON.parse(manifestBytes);
const version = manifest.schemaVersion;
const opening = readJSON(join(root, `selection-opening.v${version}.json`));
const index = readJSON(join(root, "fixture-index.v1.json"));
const observations = readJSON(join(root, `screen-observations.partial.v${version}.json`));
const validation = readJSON(join(root, `screen-validation.v${version}.json`));
const reviewResults = readJSON(reviewResultsPath);
const assignmentBytes = readFileSync(manifest.review.assignment.path);
const assignment = JSON.parse(assignmentBytes);

assert.equal(opening.manifestSha256, sha256(manifestBytes));
assert.equal(validation.manifestSha256, opening.manifestSha256);
assert.equal(sha256(assignmentBytes), manifest.review.assignment.sha256);
for (const binding of manifest.methodBindings) assert.equal(sha256(readFileSync(binding.path)), binding.sha256, binding.path);

const tokenReports = manifest.tokens.implementations.map((implementation) => readJSON(join(root, implementation.outputPath)));
for (let index = 1; index < tokenReports.length; index += 1) assert.deepEqual(tokenReports[0].records, tokenReports[index].records, "token implementations disagree");
const tokenRows = new Map(tokenReports[0].records.map((row) => [row.path, row]));
const weights = new Map(index.fixtures.map((fixture) => [fixture.id, fixture.weight]));

const gold = manifest.review.goldAnswers;
const reviewByCandidate = new Map();
for (const row of reviewResults.slots) {
  const assigned = assignment.slots.find((slot) => slot.slotId === row.slotId);
  assert.ok(assigned, `unknown review slot ${row.slotId}`);
  assert.equal(row.candidateId, assigned.candidateId);
  assert.equal(row.answers.length, gold.length);
  let correct = 0;
  for (let index = 0; index < gold.length; index += 1) if (row.answers[index] === gold[index]) correct += 1;
  reviewByCandidate.set(row.candidateId, {
    correct,
    total: gold.length,
    accuracyBasisPoints: Math.floor((correct * 10000) / gold.length),
    invalidMutationFalseAccepts: row.answers[3] === gold[3] ? 0 : 1,
    slotId: row.slotId,
    agentId: row.agentId,
  });
}

const candidateRows = [];
for (const producer of observations.candidates) {
  const independent = validation.candidates.find((row) => row.candidateId === producer.candidateId);
  assert.ok(independent);
  assert.deepEqual(producer.projectedProduction, manifest.projectedProduction[producer.candidateId]);
  let weightedTokens = 0;
  for (const fixture of index.fixtures) {
    const path = `${producer.candidateId}/${fixture.path.replace(/\.semantic\.json$/, ".source")}`;
    const token = tokenRows.get(path);
    assert.ok(token, `missing token row ${path}`);
    const bytes = readFileSync(join(root, "rendered", path));
    assert.equal(token.sha256, sha256(bytes));
    weightedTokens += token.tokens * weights.get(fixture.id);
  }
  candidateRows.push({
    candidateId: producer.candidateId,
    weightedCanonicalBytes: independent.weightedCanonicalBytes,
    weightedTokensO200kBase: weightedTokens,
    changedLines: independent.changedLines,
    changedBytes: independent.changedBytes,
    editLocality: independent.editLocality,
    editRows: independent.editRows,
    jsonFieldClosure: independent.jsonFieldClosure,
    review: reviewByCandidate.get(producer.candidateId) ?? null,
    projectedProduction: producer.projectedProduction,
  });
}

const jsonRows = candidateRows.filter((row) => manifest.roles.jsonLayouts.includes(row.candidateId));
const maximumReviewAccuracy = Math.max(...jsonRows.map((row) => row.review?.accuracyBasisPoints ?? -1));
const eligibleJSON = jsonRows.filter((row) =>
  row.jsonFieldClosure === "passed" &&
  row.editLocality === true &&
  row.review !== null &&
  row.review.invalidMutationFalseAccepts === 0 &&
  row.review.accuracyBasisPoints === maximumReviewAccuracy
);
eligibleJSON.sort((left, right) =>
  left.weightedTokensO200kBase - right.weightedTokensO200kBase ||
  left.weightedCanonicalBytes - right.weightedCanonicalBytes ||
  left.changedBytes - right.changedBytes ||
  left.changedLines - right.changedLines ||
  left.candidateId.localeCompare(right.candidateId)
);
const selectedJSON = eligibleJSON[0] ?? null;

const challenger = candidateRows.find((row) => row.candidateId === manifest.roles.possibleChallenger);
const lowerCostRows = candidateRows.filter((row) => manifest.roles.lowerCostComparators.includes(row.candidateId));
const lowerCostComparisonComplete = lowerCostRows.every((row) => row.review !== null);
const strictlyDominatesLowerCostComparators = lowerCostComparisonComplete && lowerCostRows.every((row) =>
  challenger.weightedCanonicalBytes <= row.weightedCanonicalBytes &&
  challenger.weightedTokensO200kBase <= row.weightedTokensO200kBase &&
  challenger.changedLines <= row.changedLines &&
  challenger.changedBytes <= row.changedBytes &&
  challenger.review.accuracyBasisPoints >= row.review.accuracyBasisPoints &&
  (
    challenger.weightedCanonicalBytes < row.weightedCanonicalBytes ||
    challenger.weightedTokensO200kBase < row.weightedTokensO200kBase ||
    challenger.changedLines < row.changedLines ||
    challenger.changedBytes < row.changedBytes ||
    challenger.review.accuracyBasisPoints > row.review.accuracyBasisPoints
  )
);
const challengerPredicates = selectedJSON === null ? { groupedJsonAccepted: false } : {
  groupedJsonAccepted: true,
  reviewPresent: challenger.review !== null,
  reviewAccuracy: challenger.review?.accuracyBasisPoints === 10000,
  invalidMutationFalseAccepts: challenger.review?.invalidMutationFalseAccepts === 0,
  editLocality: challenger.editLocality === true,
  byteImprovement: improvementBasisPoints(selectedJSON.weightedCanonicalBytes, challenger.weightedCanonicalBytes) >= manifest.challengerEligibility.minimumByteImprovementBasisPointsAgainstSelectedJson,
  tokenImprovement: improvementBasisPoints(selectedJSON.weightedTokensO200kBase, challenger.weightedTokensO200kBase) >= manifest.challengerEligibility.minimumTokenImprovementBasisPointsAgainstSelectedJson,
  aggregateDiffNoninferior: regressionBasisPoints(selectedJSON.changedBytes, challenger.changedBytes) <= manifest.challengerEligibility.maximumAggregateDiffRegressionBasisPoints,
  perEditDiffNoninferior: challenger.editRows.every((challengerEdit) => {
    const baselineEdit = selectedJSON.editRows.find((row) => row.editId === challengerEdit.editId);
    return baselineEdit !== undefined && regressionBasisPoints(baselineEdit.changedBytes, challengerEdit.changedBytes) <= manifest.challengerEligibility.maximumPerEditClassDiffRegressionBasisPoints;
  }),
  projectedProductionCost: regressionBasisPoints(selectedJSON.projectedProduction.loc, challenger.projectedProduction.loc) <= manifest.challengerEligibility.maximumProjectedProductionCostBasisPointsAgainstSelectedJson - 10000,
  lowerCostComparisonComplete,
  strictlyDominatesLowerCostComparators,
};
const challengerSelected = Object.values(challengerPredicates).every((value) => value === true);

const decision = {
  schemaVersion: version,
  kind: "proofkit.requirement-source-codec-screen-decision",
  manifestSha256: opening.manifestSha256,
  openingSha256: sha256(readFileSync(join(root, `selection-opening.v${version}.json`))),
  observationSha256: sha256(readFileSync(join(root, `screen-observations.partial.v${version}.json`))),
  validationSha256: sha256(readFileSync(join(root, `screen-validation.v${version}.json`))),
  tokenReportSha256: Object.fromEntries(manifest.tokens.implementations.map((implementation) => [implementation.id, sha256(readFileSync(join(root, implementation.outputPath)))])),
  reviewResultsSha256: sha256(readFileSync(reviewResultsPath)),
  candidates: candidateRows.sort((left, right) => left.candidateId.localeCompare(right.candidateId)),
  jsonEligibility: Object.fromEntries(jsonRows.map((row) => [row.candidateId, eligibleJSON.some((eligible) => eligible.candidateId === row.candidateId)])),
  selectedJsonLayout: selectedJSON?.candidateId ?? null,
  challengerPredicates,
  selectedChallenger: challengerSelected ? challenger.candidateId : null,
  stageECandidates: selectedJSON === null ? [] : ["grouped-json-v1", ...(challengerSelected ? [challenger.candidateId] : [])],
  state: selectedJSON === null ? "flat_v1_retained" : challengerSelected ? "challenger_admitted" : "grouped_json_only",
};
writeFileSync(join(root, `screen-decision.v${version}.json`), `${JSON.stringify(decision, null, 2)}\n`, { mode: 0o444 });

function improvementBasisPoints(baseline, candidate) {
  return Math.floor(((baseline - candidate) * 10000) / baseline);
}

function regressionBasisPoints(baseline, candidate) {
  return Math.max(0, Math.floor(((candidate - baseline) * 10000) / baseline));
}

function readJSON(path) {
  return JSON.parse(readFileSync(path, "utf8"));
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}
